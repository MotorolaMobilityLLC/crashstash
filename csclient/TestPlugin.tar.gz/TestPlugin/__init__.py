# Copyright 2015 Motorola Mobility
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import alf
import alf.debug
import alf.fuzz
import time

__author__ = "Tyson Smith"

class TestPlugin(alf.Fuzzer):
    """
    TestPlugin is a plugin created using the ALF framework. It is intended to
    be used for testing not as an example.
    """

    def __init__(self, template_fn):
        """Setup would be done here."""
        pass


    def do_iteration(self, mutation_fn, aggr):
        """Target automation and monitoring would be performed here."""

        if not aggr:
            result = alf.FuzzResult()
        elif mutation_fn.find('0000000A') > -1:
            result = alf.FuzzResult(
                backtrace=[alf.debug.LSO(('a', i, 1)) for i in 'abcdef'],
                classification=alf.debug.EXPLOITABLE,
                text='EXPLOITABLE result'
            )
        elif mutation_fn.find('0000000B') > -1:
            result = alf.FuzzResult(
                backtrace=[alf.debug.LSO(('a', i, 1)) for i in 'zyxwvu'],
                classification=alf.debug.UNKNOWN,
                text='UNKNOWN result'
            )
        elif mutation_fn.find('00000010') > -1:
            raise Exception('Fuzzer puked!')
        else:
            result = alf.FuzzResult()

        if result.classification != alf.debug.NOT_AN_EXCEPTION:
            with open(mutation_fn, 'w') as fp:
                fp.write('%s tc\n' % result.classification)

        time.sleep(0.001) # prevent 100% cpu since this is just a test

        return result


    def cleanup(self):
        """Cleanup would be done here."""
        pass


alf.register(TestPlugin)
